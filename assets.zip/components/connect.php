<?php
//$user_name = 'id22255580_umer';
//$user_password = 'Umer123@'
//$db_name = 'mysql:host=localhost;dbname=id22255580_bidding';
$db_name = 'mysql:host=localhost;dbname=bidding';
$user_name = 'root';
$user_password = '';

$conn = new PDO($db_name, $user_name, $user_password);

?>