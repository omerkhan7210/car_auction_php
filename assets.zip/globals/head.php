
 <head>
 <meta charset="utf-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1" />

 <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
 <link href="assets/css/jquery-ui.css" rel="stylesheet" />

 <link href="assets/css/all.min.css" rel="stylesheet" />

 <link href="assets/css/animate.min.css" rel="stylesheet" />

 <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet" />

 <link href="assets/css/fontawesome.min.css" rel="stylesheet" />

 <link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />

 <link rel="stylesheet" href="assets/css/slick.css" />
 <link rel="stylesheet" href="assets/css/slick-theme.css" />

 <link rel="stylesheet" href="assets/css/magnific-popup.css" />
 <script src="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.0/dist/boxicons.js" integrity="sha512-Dm5UxqUSgNd93XG7eseoOrScyM1BVs65GrwmavP0D0DujOA8mjiBfyj71wmI2VQZKnnZQsSWWsxDKNiQIqk8sQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

 <link href="assets/css/nice-select.css" rel="stylesheet" />

 <link rel="stylesheet" href="assets/css/style.css" />
 <link
   rel="stylesheet"
   href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css"
 />

 <link href="./assets/css/output.css" rel="stylesheet" />

  <title>Driveco - <?php echo $_SESSION['pageTitle'] ?></title>

  <link
   rel="icon"
   href="assets/img/sm-logo.svg"
   type="image/gif"
   sizes="20x20"
 />
</head>